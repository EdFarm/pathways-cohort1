//: ## Adding Values and Modifying Dictionaries
/*:
 - Syntax for addition or modification is the same
 - Use the `key` to add or modify a value for that `key`
 */
var driverBuses = ["Janet": "ABC123", "Bill": "DEF456", "Rosie": "XYZ789"]

driverBuses["Steve"] = "AEIOU2468" // Adding an element

print("\(driverBuses) <- Before")
driverBuses["Janet"] = "LMNO890" // Modifying an element
print("\(driverBuses) <- After")
//: [Previous](@previous) | [Next](@next)


import Foundation
