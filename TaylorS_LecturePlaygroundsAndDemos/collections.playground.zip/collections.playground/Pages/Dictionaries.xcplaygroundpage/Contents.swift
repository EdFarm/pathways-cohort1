//: ## Dictionaries
/*:
 - Dictionaries are collections of `key: value` pairs
 - Useful for modeling more complex data without creating new types
 - No duplicate keys
 - Dictionaries are **unordered**
 */
var driverBuses = ["Janet": "ABC123", "Bill": "DEF456", "Rosie": "XYZ789"]
print(driverBuses)
var myDictionary = [String: String]() // ["name": "busID"]
var myDictionary2 = Dictionary<String, Int>() // ["myName": 5]
var myDictionary3: [Int: String] = [:] // [12345: "Hello"]
//: [Previous](@previous) | [Next](@next)


import Foundation
