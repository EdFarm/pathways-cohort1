//: ## Nested Arrays
/*:
 - In addition to other types, you can put arrays in your arrays!
 */
var array1 = [1, 2, 3, 4, 5]
// index      0  1  2  3  4
var array2 = [6, 7, 8, 9]
// index      0  1  2  3

var nestedArray = [array1, array2]
// index of        0       1
print(nestedArray)
print(nestedArray[0])
print(nestedArray[1])
print(nestedArray[0][4])
print(array2[2])
print(nestedArray[1][2]) // nestedArray[1] = array2... array2[2] = 8
//: [Previous](@previous) | [Next](@next)


import Foundation
