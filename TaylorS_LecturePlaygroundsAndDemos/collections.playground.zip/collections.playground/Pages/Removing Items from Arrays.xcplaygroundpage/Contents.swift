//: ## Removing Items from Arrays
/*:
 */
var driverNames = ["Janet", "Bill", "Rosie"]
driverNames.insert("David", at: 2)

print("\(driverNames) <- Before")
driverNames.remove(at: 3)
print("\(driverNames) <- After")
//: [Previous](@previous) | [Next](@next)


import Foundation
