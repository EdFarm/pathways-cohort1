//: # Collections
//: ---
/*:
 ## Lesson Plan
 - Arrays
 - Dictionaries
 - Accessing Items in Collections
 - Modifying Collections
 */
//: [Previous](@previous) | [Next](@next)
