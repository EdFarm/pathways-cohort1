//: ## Defining Arrays
//: What about an array of buses?
var buses: [Bus]
let bus1 = Bus(number: "123ABC")
let bus2 = Bus(number: "456XYZ")
buses = [bus1, bus2, Bus(number: "246KLM", mileage: 12358)]
//: [Previous](@previous) | [Next](@next)


import Foundation
