//: ## Array Properties & Methods
/*:
 - As with other types, arrays have properties and methods
 - [Docs](https://developer.apple.com/documentation/swift/array) have much more detail on some of the available methods
 - [Web Docs](https://developer.apple.com/documentation/swift/array)
 */
var myArray = [1, 2, 3, 4, 5, 6]
myArray.shuffle()
print(myArray)
if myArray.count > 4 { // count property
  print("That's a lot of numbers!")
}

var has3 = myArray.contains(3) // contains() method
if has3 {
  print("we have a 3!")
}
//: [Previous](@previous) | [Next](@next)


import Foundation
