//: ## Value Methods for Dictionaries
/*:
 - Using `updateValue()` or `removeValue` returns the old value for that key, should you need it
 - These return `nil` if the key does not exist
 */
var driverBuses = ["Janet": "ABC123", "Bill": "DEF456", "Rosie": "XYZ789", "Steve": "AEIOU2468"]

let oldValue = driverBuses.updateValue("123ABC", forKey: "Janet")
print(oldValue)

let oldValue2 = driverBuses.removeValue(forKey: "Steve")
print(oldValue2)
//: [Previous](@previous) | [Next](@next)


import Foundation
