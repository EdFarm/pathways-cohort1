//: ## Array Types
/*:
 - There are several ways to define the type for an array
 */

var intArray: [Int] = []

var strArray: Array<String> =  []

var busArray = [Bus]()

var anyArray: [Any] = ["hello", 1, 2, 3.4, Bus(number: "myBus")] // beware the Any type

//: [Previous](@previous) | [Next](@next)

