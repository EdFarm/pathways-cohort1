//: ## Accessing Dictionary Values
/*:
 - Use _subscript_ syntax with the `key` to access the value
 */
var driverBuses = ["Janet": "ABC123", "Bill": "DEF456", "Rosie": "XYZ789"]

// Accessing an element
if let janetBus = driverBuses["Janet"] {
  print(janetBus)
}

print(driverBuses.keys)
let keys = Array(driverBuses.keys)
print(keys[1])
print(driverBuses[keys[1]]!)
print(driverBuses.values)

//: [Previous](@previous) | [Next](@next)


import Foundation
