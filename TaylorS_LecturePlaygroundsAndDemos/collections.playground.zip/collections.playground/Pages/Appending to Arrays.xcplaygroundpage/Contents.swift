//: ## Appending to Arrays
/*:
 - As you need to, you can add, or `append` items to the end of an array
 */
var myArray = [1, 1, 2, 3, 5, 8, 13, 21]
print("\(myArray) <- Before")

myArray.append(34) // append instance method
myArray.append(contentsOf: [55, 89]) // allows multiple items
myArray += [144, 233] // compound operator

print("\(myArray) <- After")
//: [Previous](@previous) | [Next](@next)


import Foundation
