//: ## Removing Dictionary Values
/*:
 - Set the `value` for a `key` to `nil` to remove it
 */
var driverBuses = ["Janet": "ABC123", "Bill": "DEF456", "Rosie": "XYZ789"]

driverBuses["Steve"] = "AEIOU2468"

print("\(driverBuses) <- Before")
driverBuses["Janet"] = nil // Removing an element
print("\(driverBuses) <- After")
//: [Previous](@previous) | [Next](@next)


import Foundation
