//: ## Setting Array Items
/*:
 */
var myArray = [1, 1, 2, 3, 5, 8, 13, 21]

print("\(myArray) <- Before")
myArray[0] = 0
myArray[3] = 4
myArray[6] = 30
print("\(myArray) <- After")
//: [Previous](@previous) | [Next](@next)


import Foundation
