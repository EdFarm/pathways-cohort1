//: ## Inserting Items into Arrays
/*:
 */
var driverNames = ["Janet", "Bill", "Rosie"]

print("\(driverNames) <- Before")

driverNames.insert("David", at: 2)

print("\(driverNames) <- After")
//: [Previous](@previous) | [Next](@next)


import Foundation
