import Foundation

public struct Bus: CustomStringConvertible {
  public var number: String
  public var mileage: Int = 0
  
  public init(number: String, mileage: Int = 0) {
    self.number = number
    self.mileage = mileage
  }
  
  public var description: String {
    return "Bus \(number) has a mileage of \(mileage)"
  }
}

class Person {
  var firstName: String
  var lastName: String
  
  init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
}

class Student: Person {
  var grade: Int
  
  init(firstName: String, lastName: String, grade: Int) {
    self.grade = grade
    super.init(firstName: firstName, lastName: lastName)
  }
}

class User: Person {
  var email: String
  
  init(firstName: String, lastName: String, email: String) {
    self.email = email
    super.init(firstName: firstName, lastName: lastName)
  }
}
