//: # Guard
/*:
 ## Lesson Plan
 - Happy Path/Sad Path
 - Guard
 - Guard Let
 */
//: [Previous](@previous) | [Next](@next)
