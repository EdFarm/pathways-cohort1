//: ## Guard
/*:
 - Callout(What if...)
 We could make things simpler to read?
 */
let day = "Monday"
let studentsPresent = 15
let computerSetUp = true

func teachSwift() -> String? {
  guard day == "Tuesday" || day == "Thursday" else {
    print("No class tonight!") // sad path
    return nil
  }
  
  guard studentsPresent > 0 else {
    print("No students present!") // sad path
    return nil
  }
  
  guard computerSetUp else {
    print("Set up the computer!") // sad path
    return nil
  }
  
  print("Let's learn some Swift!")
  return "Happy Times!"// happy path
}

teachSwift()

//: [Previous](@previous) | [Next](@next)


import Foundation
