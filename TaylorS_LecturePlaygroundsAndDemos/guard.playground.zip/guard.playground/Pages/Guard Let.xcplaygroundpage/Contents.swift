//: ## Guard Let
/*:
 - Callout(What about...):
 Guarding against optionals?
 */
func checkinReminder(driver: Driver) {
  guard let bus = driver.bus else {
    // sad path
    print("\(driver.firstName) can't checkin because they don't have a bus!")
    return // bail out!
  }
  
  // happy path!
  print("\(driver.firstName), please let us know where \(bus.number) is!")
}
/*:
 ---
 */
let bus = Bus(number: "ABC123")
let janet = Driver(bus: bus, email: "test@example.com", firstName: "Janet", lastName: "Walker")

checkinReminder(driver: janet)
/*:
 ---
 */
let bill = Driver(bus: nil, email: "another@example.com", firstName: "Bill", lastName: "Jenkins")

checkinReminder(driver: bill)


//: [Previous](@previous) | [Next](@next)

import Foundation
