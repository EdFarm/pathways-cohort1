//: ## Guard Let
/*:
 - Callout(If-Let Example First...):
 Seems okay... but...
 */
func checkinReminder(driver: Driver) {
  if let bus = driver.bus {
      print("\(driver.firstName), please let us know where \(bus.number) is!") // happy path
  } else {
        print("\(driver.firstName) can't checkin because they don't have a bus!") // sad path
  }
}
/*:
 ---
 */
let bus = Bus(number: "ABC123")
let janet = Driver(bus: bus, email: "test@example.com", firstName: "Janet", lastName: "Walker")

checkinReminder(driver: janet)
/*:
 ---
 */
let bill = Driver(bus: nil, email: "another@example.com", firstName: "Bill", lastName: "Jenkins")

checkinReminder(driver: bill)


//: [Previous](@previous) | [Next](@next)

import Foundation
