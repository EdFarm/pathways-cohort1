//: ## Default Values
/*:
 - You can set a default value for a property
 - A default value does not have to be included in an initializer
 - If all of the properties have a default value, the empty initializer becomes available
 - Below, `mileage` has been given a default of `0`
 */
struct Bus {
  var driverName: String = "Janet"
  var numberOfSeats: Int = 40
  var mileage: Int = 0
}

let myBus = Bus(driverName: "Bill", numberOfSeats: 30)

let bus2 = Bus(driverName: "Steve")
print(bus2)
print(myBus)

print(myBus.driverName)
//: [Previous](@previous) | [Next](@next)
