//: ## Overriding Methods
/*:
 - A superclass method can be **overridden** using the `override` keyword
 - This replaces the behavior of the superclass's method with your own
 */
class Student: Person {
  var grade: Int
  
  init(firstName: String, lastName: String, grade: Int) {
    self.grade = grade
    super.init(firstName: firstName, lastName: lastName)
  }
  
  override func displayName() -> String {
    return "\(lastName), \(firstName)"
  }
}

let aStudent = Student(firstName: "Dominic", lastName: "Torretto", grade: 8)
print(aStudent.displayName())
//: [Previous](@previous) | [Next](@next)
