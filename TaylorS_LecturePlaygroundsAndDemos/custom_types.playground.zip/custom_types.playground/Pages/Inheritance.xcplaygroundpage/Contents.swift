//: ## Inheritance
/*:
 - Classes have a superpower - **Inheritance**
 - Subclasses (children) can use the properties and methods of their superclasses (parents)
 - Here, we have a `Student` subclass of `Person`
 */

class Student: Person {
  var grade: Int
  
  init(firstName: String, lastName: String, grade: Int) {
    self.grade = grade
    super.init(firstName: firstName, lastName: lastName)
  }
}

let aStudent = Student(firstName: "Dominic", lastName: "Torretto", grade: 8)
let aPerson = Person(firstName: "Letty", lastName: "Torretto")
print(aStudent.grade)
print(aStudent.firstName)
//: [Previous](@previous) | [Next](@next)
