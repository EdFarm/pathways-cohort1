import Foundation

open class Person {
  public var firstName: String
  public var lastName: String
  
  public init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
}
