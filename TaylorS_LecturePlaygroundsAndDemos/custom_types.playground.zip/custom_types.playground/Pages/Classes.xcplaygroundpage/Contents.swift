//: ## Classes
/*:
 - Callout(Differences):
 The only difference from [Previous](@previous) is the `class` keyword
 */
class Person {
  var firstName: String
  var lastName: String
  
  init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
}

let aPerson = Person(firstName: "Dominic", lastName: "Torretto")
print(aPerson.firstName)
//: [Previous](@previous) | [Next](@next)
