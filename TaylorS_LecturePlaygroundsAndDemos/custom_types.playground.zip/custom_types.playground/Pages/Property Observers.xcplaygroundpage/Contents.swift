//: ## Property Observers
/*:
 -
 */
struct Bus {
  var driverName: String
  var numberOfSeats: Int
  var mileage: Int = 0
  let mpg: Int = 10
  var fuel: Double = 100.0 {
    willSet {
      print("Trying to set fuel from \(fuel) to \(newValue)")
    }
    didSet {
      if fuel < 0 {
        fuel = oldValue
      }
      print("Fuel is now \(fuel), and range is \(range)")
    }
  }
  
  var range: Double {
    return fuel * Double(mpg)
  }
}

var myBus = Bus(driverName: "Janet", numberOfSeats: 30, fuel: 97)
print(myBus.fuel)
myBus.fuel = 10
print(myBus.fuel)
myBus.fuel = -1
//: [Previous](@previous) | [Next](@next)
