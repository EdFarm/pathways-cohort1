//: ## Type Properties and Methods
/*:
 - The `static` keyword indicates a type property or method
 - Type properties are methods are "one per type"
 - They are used/called by using the type name, instead of an instance name
 */
struct Bus {
  static var mpg: Double = 10.0
  var driverName: String
  var numberOfSeats: Int
  var mileage: Int = 0
  var fuel: Double = 100.0
  //other code ...
  
  static func rangeWithFuel(_ fuel: Double) -> Double {
    return fuel * Double(Bus.mpg)
  }
}

var myBus = Bus(driverName: "Janet", numberOfSeats: 30, fuel: 97)
print(Bus.rangeWithFuel(50))
//: [Previous](@previous) | [Next](@next)
