//: ## Class Initializers
/*:
 - Important:
 An initializer is **REQUIRED** for a class
 */
class Person {
  var firstName: String
  var lastName: String
  
  init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
}

let aPerson = Person(firstName: "Dominic", lastName: "Torretto")
print(aPerson.firstName)
//: [Previous](@previous) | [Next](@next)
