//: ## Properties
/*:
- Data for a struct is stored in **properties**
- Properties can be any type
- Properties are `camelCased`
 */
struct Bus {
  var driverName: String
  var numberOfSeats: Int
  var mileage: Int // Added mileage here
}
//: - Callout(Next Steps):
//: Cool... but how do we make a `Bus`?
//:
//: [Previous](@previous) | [Next](@next)
