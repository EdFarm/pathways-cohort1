//: ## Reference Types
/*:
 - Classes are "Reference" types
 - When you make a copy of a reference type, you are copying a pointer to a place in memory
 - With the same pointer, changing one will change the other as well
 */

var person1 = Person(firstName: "Taylor", lastName: "Smith")
var person2 = person1

person1.lastName = "Swift"

print(person1.displayName)
print(person2.displayName)

//: [Previous](@previous) | [Next](@next)
