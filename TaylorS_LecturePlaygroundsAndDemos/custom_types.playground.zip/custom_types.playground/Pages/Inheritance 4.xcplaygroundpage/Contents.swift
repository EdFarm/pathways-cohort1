//: ## More  Subclasses
/*:
 - Callout(What if...):
 What if we need a `User` who can log in, but should also get the features of `Person`?
 What roles of `User` should we have in our app?
 */
class User: Person {
  var email: String
  
  init(firstName: String, lastName: String, email: String) {
    self.email = email
    super.init(firstName: firstName, lastName: lastName)
  }
}

class Parent: User {
  var students: [Student] = []
  // more code here...
}

class Driver: User {
  // more code here...
}
//: [Previous](@previous) | [Next](@next)
