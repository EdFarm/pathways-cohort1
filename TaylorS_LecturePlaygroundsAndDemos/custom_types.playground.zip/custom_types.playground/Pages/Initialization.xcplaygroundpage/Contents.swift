//: ## Initialization
/*:
 - We can create an **instance** of a `Bus`
 - After _initializing_ (or _instantiating_) `myBus` we can access its properties using dot (`.`) syntax.
 */
struct Bus {
  var driverName: String
  var numberOfSeats: Int
  var mileage: Int
}

let myBus = Bus(driverName: "Bill", numberOfSeats: 30, mileage: 54321)

print(myBus)
/*:
 - Callout(Alternate Syntax):
 `Bus.init()` is another way to initialize, but the `.init` is not required and not often used
 */
//: [Previous](@previous) | [Next](@next)
