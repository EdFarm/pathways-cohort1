//: # What's your Type?
//: ## An Introduction to Structs and Classes
//: ## Lesson Plan
/*:
 - Structures (Structs)
 - Classes
 - Inheritance
 - Value vs Reference Types
 - When to use a struct or class for your type
 */
//: [Onward to Structs](@next)
