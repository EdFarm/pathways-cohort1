//: ## Superclass Methods
/*:
 - Callout(Differences):
 We've added the `displayName()` method to our Person superclass
 */
class Person {
  var firstName: String
  var lastName: String
  
  init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
  
  func displayName() -> String {
    return "\(firstName) \(lastName)"
  }
}

let aPerson = Person(firstName: "Dominic", lastName: "Torretto")
print(aPerson.displayName())
//: [Previous](@previous) | [Next](@next)
