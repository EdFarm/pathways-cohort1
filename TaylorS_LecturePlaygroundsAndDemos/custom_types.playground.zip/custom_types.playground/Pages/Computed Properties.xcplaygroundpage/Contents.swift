//: ## Computed Properties
/*:
 - A computed property gets its value from other properties in the type
 - 
 */
struct Bus {
  var driverName: String
  var numberOfSeats: Int
  var mileage: Int = 0
  var fuel: Double = 100.0
  let mpg: Int = 10
  
  var range: Double {
    return fuel * Double(mpg)
  }
}

var myBus = Bus(driverName: "Janet", numberOfSeats: 30, fuel: 97)
print(myBus.range)
//: [Previous](@previous) | [Next](@next)
