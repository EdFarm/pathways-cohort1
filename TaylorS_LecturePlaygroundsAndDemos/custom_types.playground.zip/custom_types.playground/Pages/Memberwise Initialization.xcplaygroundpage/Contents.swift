//: ## Memberwise Initialization
/*:
 - When creating an instance of a struct, we can use a memberwise initalizer
 - A memberwise initializer is created automatically by the Swift compiler
 - Properties are listed in the order they are defined in the struct
 */
struct Bus {
  var driverName: String
  var numberOfSeats: Int
  var mileage: Int
}

let myBus = Bus(driverName: "Janet", numberOfSeats: 30, mileage: 54321)
print(myBus.driverName)
/*:
 - Important:
 Each property **MUST** have a value after initialization
 */
//: [Previous](@previous) | [Next](@next)
