//: ## Using "self"
/*:
 - Inside of an instance, `self` refers to that instance
 - Not required **EXCEPT** when you need to clarify ambiguity
 - Our argument names and property names are the same in the initializer, so we must use `self` to disambiguate
 */
struct Bus {
  var driverName: String
  var numberOfSeats: Int
  var mileage: Int
  
  init(driverName: String, numberOfSeats: Int, mileage: Int) {
    self.driverName = driverName
    self.numberOfSeats = numberOfSeats
    self.mileage = mileage
  }
}

let myBus = Bus(driverName: "Janet", numberOfSeats: 30, mileage: -200)
print(myBus.mileage)
//: [Previous](@previous) | [Next](@next)
