/*:
 ## Structs
 ### Basic Syntax
 1. Structures introduce a new keyword, `struct`
 1. Structs allow us to build new **types** (Like `String`, `Int`, `Bool`, etc.)
 1. Structs can have **data** _and_ **behavior**
 
 ---
 Structs are named
 The Bus `struct` below only has properties at the moment
 */
struct Bus {
  var driverName: String
  var numberOfSeats: Int
}
//: - Callout(Next Steps):
//: What if we wanted to store `mileage`?
//:
//: [Previous](@previous) | [Next](@next)
