//: ## Methods
/*:
 - Functions contained within a type are called **methods**
 - Instance methods give _behavior_ to your types
 - Instances of a type _call_ the methods, and may use the properties of that specific instance
 */
struct Bus {
  var driverName: String
  var numberOfSeats: Int
  var mileage: Int
  
  func needsService() -> Bool {
    return mileage > 5000
  }
}

let myBus = Bus(driverName: "Janet", numberOfSeats: 30, mileage: 3500)
print(myBus.needsService())
let anotherBus = Bus(driverName: "Bill", numberOfSeats: 48, mileage: 7654)
print(anotherBus.needsService())
//: [Previous](@previous) | [Next](@next)
