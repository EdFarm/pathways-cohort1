import UIKit

var str = "Hello, playground"

// Bus struct
struct Bus {
  // Properties
  var id: String
  var driver: Driver
  var numberOfSeats: Int
  var speed: Double
  var students: [Student]
  
  // computed properties
  var speedMetric: Double {
//     https://www.rapidtables.com/convert/length/mile-to-km.html
    return speed * 1.609344
  }

  // Methods
  func isFull() -> Bool {
    return numberOfSeats == students.count
  }
}

class Person {
  var id: String
  var firstName: String
  var lastName: String
  
  init(id: String, firstName: String, lastName: String) {
    self.id = id
    self.firstName = firstName
    self.lastName = lastName
  }
}

// subclass of person with student features
class Student: Person {
  var age: Int
  var grade: Int
  var busID: String
  
  init(id: String, firstName: String, lastName: String, age: Int, grade: Int, busID: String) {
    self.age = age
    self.grade = grade
    self.busID = busID
    super.init(id: id, firstName: firstName, lastName: lastName)
  }
}

// subclass of person to allow for typical user login features
class User: Person {
  var email: String
  
  init(id: String, firstName: String, lastName: String, email: String) {
    self.email = email
    super.init(id: id, firstName: firstName, lastName: lastName)
  }
}

// subclass of user - useful for specifying role/permissions
class Driver: User {
  var bus: Bus
  
  init(id: String, firstName: String, lastName: String, email: String, bus: Bus) {
    self.bus = bus
    super.init(id: id, firstName: firstName, lastName: lastName, email: email)
  }
}

// subclass of user - useful for specifying role/permissions
class Parent: User {
  // parent may have many students
  var students: Array<Student>
  
  init(id: String, firstname: String, lastName: String, email: String, students: [Student]) {
    self.students = students
    super.init(id: id, firstName: firstname, lastName: lastName, email: email)
  }
}

//: [Classes](Classes)
