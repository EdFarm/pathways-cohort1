import Foundation

public struct Bus {
  public var driverName: String
  public var numberOfSeats: Int
  public var mileage: Int
  
  public init(driverName: String, numberOfSeats: Int, mileage: Int) {
    self.driverName = driverName
    self.numberOfSeats = numberOfSeats
    self.mileage = mileage
  }
}
