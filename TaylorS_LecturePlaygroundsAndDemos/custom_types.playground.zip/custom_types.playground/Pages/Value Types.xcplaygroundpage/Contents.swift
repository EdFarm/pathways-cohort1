//: ## Value Types
/*:
 - Structs are "Value" types
 - When you make a copy of a value type, you are copying all of the properties into a new instance
 - The two instances can be changed independently
 */
var bus1 = Bus(driverName: "Bill", numberOfSeats: 45, mileage: 12345)
var bus2 = bus1

bus1.mileage = 123456

print(bus1.mileage)
print(bus2.mileage)

//: [Previous](@previous) | [Next](@next)
