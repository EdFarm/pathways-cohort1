//: ## Another Struct
/*:
 - Callout(What if...):
 We need somebody to ride/drive the bus...
 */
struct Person {
  var firstName: String
  var lastName: String
  
  init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
}

let aPerson = Person(firstName: "Dominic", lastName: "Torretto")
print(aPerson.firstName)
//: [Previous](@previous) | [Next](@next)
