//: ## Structs or Classes?
/*:
 - Start with a struct
 - If you realize you need inheritance, you can quickly move to classes
 - You will most often see classes in UIKit, where _EVERYTHING_ is a class
 - If you're working with code that uses a lot of classes, you may want to use classes as well to be able to leverge inheritance with what's already there
 - If you need to use the features of reference types to have access to the same object around your code
 - There is another way to share capabilities... we'll get there later...
 */
//: [Previous](@previous) | [Next](@next)
