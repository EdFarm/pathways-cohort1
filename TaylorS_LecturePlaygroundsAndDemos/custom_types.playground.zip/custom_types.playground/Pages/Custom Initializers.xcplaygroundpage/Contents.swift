//: ## Custom Initializers
/*:
 - In addition to the memberwise initializers, you can write your own
 - If you include a custom initializer, the Swift generated memberwise initializer is removed
 */
struct Bus {
  var driverName: String
  var numberOfSeats: Int
  var mileage: Int
  
  init(driverName: String, numberOfSeats: Int, mileage: Int) {
    self.driverName = driverName
    self.numberOfSeats = numberOfSeats
    if (mileage < 0) {
      self.mileage = 0
    } else {
      self.mileage = mileage
    }
  }
}

let myBus = Bus(driverName: "Janet", numberOfSeats: 30, mileage: -200)
print(myBus.mileage)
//: [Previous](@previous) | [Next](@next)
