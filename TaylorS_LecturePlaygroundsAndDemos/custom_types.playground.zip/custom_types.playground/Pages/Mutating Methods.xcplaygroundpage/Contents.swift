//: ## Mutating Methods
/*:
 - Use the `mutating` keyword at the beginning of a method definition to indicate that it can modify a property
 - A variable instance of a type is required to use mutating methods
 - `mutating` is not required in classes
 */
struct Bus {
  var driverName: String
  var numberOfSeats: Int
  var mileage: Int
  var fuel: Double = 100.0
  var mpg: Double = 10

  mutating func drive(miles: Int = 1) {
    mileage += miles
    fuel -= Double(miles) / Double(mpg)
    mpg += 0.00001 * Double(miles)
  }
}

var myBus = Bus(driverName: "Janet", numberOfSeats: 30, mileage: 3500)
myBus.drive()
print(myBus)
myBus.drive(miles: 30000)
print(myBus)
//: [Previous](@previous) | [Next](@next)
