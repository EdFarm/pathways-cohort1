//: ## Copyright 2020
/*:
 Taylor Smith
 - Callout(Email):
 [tsmith@motionmobs.com](mailto:tsmith@motionmobs.com)
 
 */
/*:
 - Callout(Twitter):
 [@rendersmith](https://twitter.com/rendersmith)
 */
