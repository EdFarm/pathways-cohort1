//: ## Shadowing
/*:
 - Callout(What if...): We want to use the same variable name inside and outside of a particular scope?
 */
let bus = Bus(number: "ABC123") // set somewhere in our code...

let janetBus = Bus(number: "XYZ789")
var driverEmail = "janet@example.com" // global scope
let janet = Driver(bus: janetBus, email: "test@example.com", firstName: "Janet", lastName: "Walker")

// emailDriver provides email contact information for a specific driver
func emailDriver(_ driver: Driver) {
  let driverEmail = driver.email // local scope
  
  if let bus = driver.bus {
//    let driverEmail = "another@example.com" // deeper scope
    print("Send email to \(driverEmail) to reach the driver for bus #\(bus.number)")
  }
}

// run it...
emailDriver(janet)
//: [Previous](@previous) | [Next](@next)


import Foundation
