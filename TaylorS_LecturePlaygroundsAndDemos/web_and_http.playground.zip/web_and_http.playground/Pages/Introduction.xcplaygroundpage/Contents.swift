//: # HTTP & URL Session
//: ---
/*:
 ## Lesson Plan
 - Working with the Web
 - URL Structure
 - Request Details
 - Making Requests
 - What's an API?
 - Connecting to an API
 - Things to Consider
 */
//: [Previous](@previous) | [Next](@next)
