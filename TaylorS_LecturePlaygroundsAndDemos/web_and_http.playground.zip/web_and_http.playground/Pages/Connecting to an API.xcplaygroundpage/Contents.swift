//: ## Connecting to an API
/*:
 - callout(What if...): We wanted to get our list of buses from the API?
 - Here, we connect to the AirTable API that we're using to handle our bus data
 */
import Foundation
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

let busURLString = "https://api.airtable.com/v0/appJcnNAwDRF4czQX/Buses?pageSize=10&api_key=keyYZP8dh2EYwmC3Q"

let url = URL(string: busURLString)!

let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
  if let data = data, let string = String(data: data, encoding: .utf8) {
    print(string)
  }
  PlaygroundPage.current.finishExecution()
}

task.resume()
//: [Previous](@previous) | [Next](@next)



