//: ## Things to Consider
/*:
 - Device may have a slow connection to the network
 - Some users may have limits on their data plan, so use that data efficiently!
 - Any network request will take time, and potentially make your app "feel" slower
 - Devices may launch your app connected but may lose connection at any point
 - Device may not be connected to the network at all!
 */

//: [Previous](@previous) | [Next](@next)


import Foundation
