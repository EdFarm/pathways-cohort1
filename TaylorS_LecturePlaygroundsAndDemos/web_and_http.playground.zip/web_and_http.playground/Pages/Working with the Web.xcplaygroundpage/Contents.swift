//: ## Working with the Web
/*:
 - Most apps connect with the web
 - Devices may connect with Wi-Fi or over a cellular network
 - Apps will often need to receive AND send data over the network
 - Requests and Responses
 - Requests are asynchronous!
 - Apps connect to servers using the same techniques as web browsers
 */
//: ![web_request](web_request.png)
//: [Previous](@previous) | [Next](@next)


import Foundation
