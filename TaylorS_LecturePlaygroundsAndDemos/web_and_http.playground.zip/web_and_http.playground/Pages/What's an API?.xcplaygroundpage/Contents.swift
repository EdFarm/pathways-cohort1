//: ## What's an API?
/*:
 - Application Programming Interface (API)
 - We've been using APIs this whole time!
 - Web APIs are sites or services accessed through various network requests
 - Web APIs (good ones, at least) include public documentation and examples to help guide you in their use and expectations
 */
//: [Previous](@previous) | [Next](@next)


import Foundation
