//: ## Creating URLs
/*:
 - Information
 */
// code here
//: [Previous](@previous) | [Next](@next)
let busURLString = "https://api.airtable.com/v0/appJcnNAwDRF4czQX/Buses?pageSize=10&api_key=keyZ8d2EwmCQ"

import Foundation
