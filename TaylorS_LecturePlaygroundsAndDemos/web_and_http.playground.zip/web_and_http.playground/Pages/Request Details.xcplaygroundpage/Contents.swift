//: ## Request Details
/*:
 - Requests are more than just the URL!
 - Request Types
   - GET => (Default) Fetches single or list of information
   - POST/PUT => Includes data in the body of the request to be used by server
   - DELETE => Server should delete/destroy something as a result of this type
 - Headers are extra data passed to or from the server
   - Dictionary-like structure of key/value pairs
   - Not useful to the typical user, but useful information for the server
   - Authentication tokens and API keys are often sent as headers
   - Cookies are delivered to your browser via headers
 - Requests and responses may include data in the Body
 - Asynchronous Execution using multiple threads and queues
 - Separate queues allow for UI to keep running smoothly while other work is done for the app
 */
//: [Previous](@previous) | [Next](@next)


import Foundation
