import Foundation
//: ## Making Requests
/*:
 - `URLSession` - handler for a group of related network requests
 - `URLSessionDataTask` - basic data request task executed by the session
 - There are other task types to handle uploads, downloads, and websocket tasks
 - `Completion handler` - function run with the response data after the request is completed
 */
// setup for web requests...
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

let url = URL(string: "https://www.apple.com")! // build url
// building our task (request)
let task = URLSession.shared.dataTask(with: url, completionHandler: {
  (data, response, error) in
  if let data = data,
    let string = String(data: data, encoding: .utf8) {
    print(string)
  }
  PlaygroundPage.current.finishExecution()
})

task.resume() // make request

// another way to write the closure
//let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
//  if let data = data,
//    let string = String(data: data, encoding: .utf8) {
//    print(string)
//  }
//  PlaygroundPage.current.finishExecution()
//}
//: [Previous](@previous) | [Next](@next)


