import Foundation
//: ## URLs
/*:
 - Same as a web browser
 - Made up of a set of standard components
 */
let busURLString = "https://api.airtable.com/v0/appJcnNAwDRF4czQX/Buses?pageSize=10&api_key=keyYZP8dh2EYwmC3Q"

let urlProtocol = "https"
let subdomain = "api"
let domain = "airtable.com"
let path = "v0/appJcnNAwDRF4czQX/Buses"
let apiKey = "keyYZP8dh2EYwmC3Q"
let queryParameters = "pageSize=10&api_key=\(apiKey)"

let busURLAssembled = "\(urlProtocol)://\(subdomain).\(domain)/\(path)?\(queryParameters)"

print(busURLString)
print(busURLAssembled)

// acceptable to use ! here
// if your app crashes, something's wrong with your URL
let url = URL(string: busURLString)!
//: [Previous](@previous) | [Next](@next)

