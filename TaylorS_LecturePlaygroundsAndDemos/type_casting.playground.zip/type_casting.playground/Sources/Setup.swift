import Foundation

public class Bus: CustomStringConvertible {
  public var number: String
  public var mileage: Int = 0
  
  public init(number: String, mileage: Int = 0) {
    self.number = number
    self.mileage = mileage
  }
  
  public var description: String {
    return "Bus \(number) has a mileage of \(mileage)"
  }
}

public class Person {
  public var firstName: String
  public var lastName: String?
  
  public init(firstName: String, lastName: String?) {
    self.firstName = firstName
    self.lastName = lastName
  }
}

public class User: Person {
  public var email: String
  
  public init(email: String, firstName: String, lastName: String?) {
    self.email = email
    super.init(firstName: firstName, lastName: lastName)
  }
}

public class Student: Person {
  public var bus: Bus?
  
  public init(bus: Bus?, firstName: String, lastName: String?) {
    self.bus = bus
    super.init(firstName: firstName, lastName: lastName)
  }
}

public class Driver: User {
  public var bus: Bus?
  
  public init(bus: Bus?, email: String, firstName: String, lastName: String?) {
    self.bus = bus
    super.init(email: email, firstName: firstName, lastName: lastName)
  }
}

public class Parent: User {
  public var students: [Student]
  
  public init(students: [Student], email: String, firstName: String, lastName: String?) {
    self.students = students
    super.init(email: email, firstName: firstName, lastName: lastName)
  }
}

public let driver = Driver(bus: nil, email: "driver@example.com", firstName: "Janet", lastName: "Driver")

public let student = Student(bus: nil, firstName: "Billy", lastName: "Jenkins")

public let person = Person(firstName: "Steve", lastName: "Smith")

public let parent = Parent(students: [], email: "test@example.com", firstName: "Alice", lastName: "Walker")

public let user = User(email: "user@example.com", firstName: "User", lastName: "Name")

public let bus = Bus(number: "ABC123", mileage: 0)

public let exampleOptions: [Person] = [student, driver, person, parent, user]

public func randomPerson() -> Person {
  let exampleIndex = Int.random(in: 0..<exampleOptions.count)
  return exampleOptions[exampleIndex]
}
