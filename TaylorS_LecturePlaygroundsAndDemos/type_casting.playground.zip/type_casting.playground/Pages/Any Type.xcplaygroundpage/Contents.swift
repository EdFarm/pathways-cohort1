//: ## Any
/*:
 - Callout(What if...):
 We need to use multiple types, or don't know the types while we're building our code?
 */
let anyArray: [Any] = [bus, person, student, driver, 1, "another"]

let anyIndex = Int.random(in: 0..<anyArray.count)
let item = anyArray[anyIndex]

// here we use instrospection to determine type of item
if item is Bus {
  print("I'm a bus!")
} else if item is Student {
  print("I'm a student!")
} else if item is Driver {
  print("I'm a driver!")
} else if item is Person {
  print("I'm a person!")
} else if item is Int {
  print("I'm an integer!")
} else if item is String {
  print("I'm a string!")
}

// as? is similar to optional use
if let aBus = anyArray[0] as? Bus {
  print("Bus number is \(aBus.number)")
} else {
  print("I'm not a bus. Sorry!")
}

// as! is dangerous -- avoid if possible
let aPerson = anyArray[1] as! Person
print("\(aPerson.firstName)")

if let aPersonSafely = anyArray[1] as? Person {
  print("\(aPersonSafely.firstName)")
}

// this will break -- have fun!
//let aPersonAny = anyArray[1]
//print("\(aPersonAny.firstName)")

//: if we want to get away from `Any` in our data
let splitDictionary: [String: [Any]] = ["buses": [bus], "people":[person, student, driver]]

if let dictionaryPeople = splitDictionary["people"] as? [Person] {
  print("hooray!")
}
//: [Previous](@previous) | [Next](@next)


import Foundation
