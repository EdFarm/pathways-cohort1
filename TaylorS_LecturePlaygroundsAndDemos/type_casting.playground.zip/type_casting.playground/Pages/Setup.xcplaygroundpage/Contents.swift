//: ## Setup
/*:
 - callout(Setting this up):
 Below we've built out the classes we'll uses along the way through our code
 */
class Person {
  var firstName: String
  var lastName: String?
  
  init(firstName: String, lastName: String?) {
    self.firstName = firstName
    self.lastName = lastName
  }
}

public struct Bus {
  public var number: String
  public var mileage: Int = 0
}

class User: Person {
  var email: String
  
  init(email: String, firstName: String, lastName: String?) {
    self.email = email
    super.init(firstName: firstName, lastName: lastName)
  }
}

class Student: Person {
  var bus: Bus?
  
  init(bus: Bus?, firstName: String, lastName: String?) {
    self.bus = bus
    super.init(firstName: firstName, lastName: lastName)
  }
}

class Driver: User {
  var bus: Bus?
  
  init(bus: Bus?, email: String, firstName: String, lastName: String?) {
    self.bus = bus
    super.init(email: email, firstName: firstName, lastName: lastName)
  }
}

class Parent: User {
  var students: [Student]
  
  init(students: [Student], email: String, firstName: String, lastName: String?) {
    self.students = students
    super.init(email: email, firstName: firstName, lastName: lastName)
  }
}
//: [Previous](@previous) | [Next](@next)


import Foundation
