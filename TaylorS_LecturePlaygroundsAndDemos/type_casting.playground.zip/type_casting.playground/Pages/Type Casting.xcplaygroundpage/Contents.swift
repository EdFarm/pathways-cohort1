//: ## Type Casting
/*:
 - How do we use an object after inspecting its type?
 */
func driveBus(driver: Driver) {
  if let bus = driver.bus {
    print("\(driver.firstName) is driving bus number \(bus.number)!")
  } else {
    print("\(driver.firstName) has no bus!")
  }
}

let people: [Person] = [driver, user, person]

for person in people { // person is Person type
  if person is Driver { // inspect type
//    driveBus(driver: person) // doesn't work?
  }
}
//: have to cast using `as?`
for person in people {
  print(person)
//  let driver = person as! Driver // this will crash!
  // driveBus(driver: driver)
  if let driver = person as? Driver {
    driveBus(driver: driver)
  }
}

//: [Previous](@previous) | [Next](@next)

import Foundation
