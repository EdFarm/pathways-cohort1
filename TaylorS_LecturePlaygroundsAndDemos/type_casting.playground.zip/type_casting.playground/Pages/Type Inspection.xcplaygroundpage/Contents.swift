//: ## Type Inspection
/*:
 - We can use the `is` keyword to "inspect" the type of an instance.
 */

let exampleOptions: [Person] = [student, driver, person, parent, user]
let exampleIndex = Int.random(in: 0..<exampleOptions.count)
let example = exampleOptions[exampleIndex]

if example is Person {
  print("Hello, I'm a Person!")
} else {
  print("Hello!")
}

if example is User {
  print("I'm a User!")
  if example is Parent {
    print("I'm a Parent!")
  } else if example is Driver {
    print("I'm a Driver!")
  }
} else if example is Student {
  print("I'm a Student!")
}



//: [Previous](@previous) | [Next](@next)


import Foundation
