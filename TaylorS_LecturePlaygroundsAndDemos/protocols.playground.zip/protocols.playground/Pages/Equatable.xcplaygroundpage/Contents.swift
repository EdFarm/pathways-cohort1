//: ## Equatable
/*:
 - callout(What if...): determine if two instances of our custom type are equal?
 - Allows us to build custom logic to determine if two instances are equal to each other
 - Built into Swift by default
 */
class Student: Equatable {
  var firstName: String
  var lastName: String
  var school: String
  var grade: Int
  
  init(firstName: String, lastName: String, school: String, grade: Int) {
    self.firstName = firstName
    self.lastName = lastName
    self.school = school
    self.grade = grade
  }
  
  // required to conform to Equatable protocol
  static func == (lhs: Student, rhs: Student) -> Bool {
    // build out equatable tests here
    return lhs.firstName == rhs.firstName && lhs.lastName == rhs.lastName && lhs.school == rhs.school && lhs.grade == rhs.grade
  }
}

let student1 = Student(firstName: "Taylor", lastName: "Smith", school: "A Great School", grade: 12)
let student2 = Student(firstName: "Taylor", lastName: "Smith", school: "A Great School", grade: 12)

if (student1 == student2) {
  print("The students are equal!")
  // ... or other code if they match...
} else {
  print("The students are not equal")
}
//: [Previous](@previous) | [Next](@next)
import Foundation
