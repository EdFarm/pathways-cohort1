//: ## Comparable
/*:
 - callout(What if...): we want to be able to sort our custom types based on their properties?
 - Built into Swift by default
 */
class Driver: Comparable, CustomStringConvertible {
  var firstName: String
  var lastName: String
  
  var description: String {
    return "(\(lastName), \(firstName))"
  }
  init(_ firstName: String, _ lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
  
//  required to conform to Comparable protocol
  static func < (lhs: Driver, rhs: Driver) -> Bool {
    return lhs.lastName < rhs.lastName
  }
  
  // required by inheritance from Equatable
  static func == (lhs: Driver, rhs: Driver) -> Bool {
    return lhs.firstName == rhs.firstName && lhs.lastName == lhs.lastName
  }
}

let driver1 = Driver("Janet", "Warner")
let driver2 = Driver("Steve", "Appleton")
let driver3 = Driver("James", "Michaels")
let driver4 = Driver("Dominic", "Toretto")

let drivers = [driver1, driver2, driver3, driver4]
print(drivers)

let sortedDrivers = drivers.sorted() // using Comparable protocol
print(sortedDrivers)
//: [Previous](@previous) | [Next](@next)
import Foundation
