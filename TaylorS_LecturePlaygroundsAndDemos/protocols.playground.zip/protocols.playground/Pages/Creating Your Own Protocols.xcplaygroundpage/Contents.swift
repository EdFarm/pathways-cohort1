//: ## Creating Your Own Protocols
/*:
 - 
 */
protocol Flyable {
  // protocol property
  var airspeed: Double { get set }
  
  // protocol method
  func isFlying() -> Bool
}

class Animal {
  // ... more code for the class here...
}
class Mammal: Animal {}
class Bird: Animal {}
class Penguin: Bird {}
class Parrot: Bird, Flyable {
  var airspeed: Double
  
  func isFlying() -> Bool {
    return airspeed > 10
  }
  
  init(airspeed: Double) {
    self.airspeed = airspeed
    super.init()
  }
}

class Vehicle {}
class Car: Vehicle {}
class Plane: Vehicle, Flyable {
  var airspeed: Double
  
  func isFlying() -> Bool {
    return airspeed > 180
  }
  
  init(airspeed: Double) {
    self.airspeed = airspeed
    super.init()
  }
}


let flyables: [Flyable] = [Parrot(airspeed: 10), Plane(airspeed: 200)]

for flier in flyables {
  print("\(flier.isFlying())")
}
//: [Previous](@previous) | [Next](@next)


import Foundation
