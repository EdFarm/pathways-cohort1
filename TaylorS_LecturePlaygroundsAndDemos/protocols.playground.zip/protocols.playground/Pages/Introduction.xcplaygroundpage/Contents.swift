//: # Protocols
//: ---
/*:
 ## Lesson Plan
 - What's a Protocol?
 - Why do we need Protocols?
 - CustomStringConvertible
 - Equatable
 - Comparable
 - Codable
 - Writing our own Protocols
 - Delegation
 */
//: [Previous](@previous) | [Next](@next)
