//: ## Codable
/*:
 - callout(What if...): We want to store our data in our app or convert data coming from a web server?
 - Automatic if all properties conform to Codable already (Most Swift standard library types do!)
 - Built into Swift by default
 */
import Foundation
struct Bus: CustomStringConvertible, Codable {
  var number: String
  var seats: Int
  
  // conforming to CustomStringConvertible
  var description: String {
    return "Bus #\(number) has \(seats) seats"
  }
}

let bus1 = Bus(number: "ABC123", seats: 45)

let jsonEncoder = JSONEncoder()
if let jsonData = try? jsonEncoder.encode(bus1), let jsonString = String(data: jsonData, encoding: .utf8) {
  print(jsonString)
  // ... or save jsonString to the device...
  // ... or send jsonString to a web server...
}

//: [Previous](@previous) | [Next](@next)
