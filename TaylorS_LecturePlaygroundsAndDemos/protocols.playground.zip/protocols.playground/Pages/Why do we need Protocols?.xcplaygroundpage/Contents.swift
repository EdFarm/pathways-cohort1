//: ## Why do we need Protocols?
//: ![Flyable Example](flyable_example.png)

//: - callout(What if...): What if we wanted to add "Flyable" functionality to this class structure?
//: [Previous](@previous) | [Next](@next)

import Foundation
