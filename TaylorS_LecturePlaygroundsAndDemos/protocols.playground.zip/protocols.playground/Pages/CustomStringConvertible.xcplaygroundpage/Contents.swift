//: ## CustomStringConvertible
/*:
 - callout(What if...): we want to print out information about our custom types?
 - Allows us to print what we want about our types in a more legible way
 - Built into Swift by default
 */
struct Bus: CustomStringConvertible {
  var number: String
  var seats: Int
  
  // conforming to CustomStringConvertible
  var description: String {
    return "Bus #\(number) has \(seats) seats"
  }
}

let bus1 = Bus(number: "ABC123", seats: 45)
print(bus1)
//: [Previous](@previous) | [Next](@next)
import Foundation
