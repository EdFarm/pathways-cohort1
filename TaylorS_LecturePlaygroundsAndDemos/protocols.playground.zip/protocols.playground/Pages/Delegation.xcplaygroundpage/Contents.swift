//: ## Delegation
/*:
 - Allows one object to call upon another to do work for it
 - Allows for flexible separation of responsibility
 - Is very often used in UIKit
 */
protocol BusRouteDelegate {
  func updateRoute(bus: Bus)
}

struct RouteManager: BusRouteDelegate {
  func updateRoute(bus: Bus) {
    print("updating route for bus \(bus.number)")
    // ... and possibly check current schedule and timing...
    // ... and possibly updating route in Driver UI...
    // ... and possibly sending messages to parents...
  }
}

struct Bus {
  var number: String
  var seats: Int
  var routeDelegate: BusRouteDelegate
  
  func beginDriving() {
    routeDelegate.updateRoute(bus: self)
  }
  
  func arriveAtStop() {
    routeDelegate.updateRoute(bus: self)
  }
}

let manager = RouteManager()

let bus = Bus(number: "ABC123", seats: 40, routeDelegate: manager)
bus.beginDriving()

bus.arriveAtStop()

//: [Previous](@previous) | [Next](@next)

import Foundation
