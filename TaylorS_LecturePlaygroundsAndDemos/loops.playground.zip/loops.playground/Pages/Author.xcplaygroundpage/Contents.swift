//: ## Copyright 2020
/*:
 Taylor Smith
 
 Email - [tsmith@motionmobs.com](mailto:tsmith@motionmobs.com)
 
 Twitter - [@rendersmith](https://twitter.com/rendersmith)
 
 */
