//: ## For Loop Syntax
/*:
 - Loops run repeatedly
 - For loops run once for each item in a range
 */
for numberValue in 1...6 {
  print(numberValue)
}

// No index needed, so we use `_`
let delay = 10
for _ in 1...5 {
  print("Hello, is this annoying yet?")
//  sleep(forTimeInterval: delay)
  print("this is another print")
}
//: [Previous](@previous) | [Next](@next)


import Foundation
