//: ## For Loop with Dictionaries
/*:
 - For loops also work with dictionaries
 - Instead of just the index, you get the `key` and `value` to use
 */
let nameBuses: [String: Bus] = [
  "Janet": Bus(number: "ABC123"),
  "Bill": Bus(number: "XYZ987"),
  "Bob": Bus(number: "JKL246", mileage: 12345)
]

for (driver, bus) in nameBuses {
  print("\(driver) is the driver of bus \(bus.number)")
}
//: [Previous](@previous) | [Next](@next)


import Foundation
