//: ## For Loop with Arrays
/*:
 - For loops can also be used with collections
 - The loop is run once per item in the collection
 */
let words = ["Hello", "there", "how", "are", "you?"]
for word in words {
  print(word)
}
//: [Previous](@previous) | [Next](@next)


import Foundation
