//: ## For Loop with Buses
/*:
 - What if we wanted to loop through an array of buses?
 */
let buses = [Bus(number: "ABC123", mileage: 36912), Bus(number: "XYZ987", mileage: 12358), Bus(number: "JKL246")]

for bus in buses {
  if bus.mileage > 15000 {
    print("Bus \(bus.number) needs service with \(bus.mileage) miles.")
  } else {
    print("Bus \(bus.number) does not need service with \(bus.mileage) miles.")
  }
}
//: [Previous](@previous) | [Next](@next)


import Foundation
