//: ## Enumerated Strings
/*:
 */
let word = "letters"
// use the .enumerated() method on a string to get (index, letter) tuple
for (index, letter) in word.enumerated() {
  print("\(index) is \(letter)")
}
//: [Previous](@previous) | [Next](@next)


import Foundation
