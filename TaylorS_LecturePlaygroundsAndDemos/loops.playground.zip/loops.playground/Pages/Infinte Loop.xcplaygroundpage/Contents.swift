//: ## Infinte Loop!?
/*:
 - Oh NO...
 */
//while true {
//  print("hello! hey! HEEEEYYY!")
//}
//: [Previous](@previous) | [Next](@next)


import Foundation
