//: ## Control Transfer
/*:
 - What if we wanted to stop our loop early?
 */
for value in 0...10 {
  let remainder = value % 2 // 6 % 2 = 0, 7 % 2 = 1
  if remainder == 0 { // is number divisible by 2?
    continue // moves on to the next iteration in the loop
  }
  print("\(value) is odd")
}

var counter = 1
while counter < 100 {
  if counter % 10 == 0 {
    print("Found that \(counter) is divisible by 10! Stopping now!")
    break // "breaks" out of the loop
  }
  counter += 1
}
print("next!")
//: [Previous](@previous) | [Next](@next)


import Foundation
