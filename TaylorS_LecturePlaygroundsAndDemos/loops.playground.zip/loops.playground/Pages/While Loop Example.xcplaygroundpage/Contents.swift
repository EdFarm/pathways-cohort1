//: ## While Loops Example
/*:
 - What if we wanted to keep checking for a change? 
 */
var counter = 1
func updateBuses() {
  let randomInt = Int.random(in: 1...30)
  if randomInt <= busesAway {
    busesAway -= randomInt
    print("\(randomInt) bus(es) parked, \(busesAway) remain")
  }
  print("Run \(counter) time, randomInt was \(randomInt)")
  counter += 1
}

var busesAway = 10
while busesAway > 0 {
  updateBuses()
}
//: [Previous](@previous) | [Next](@next)


import Foundation
