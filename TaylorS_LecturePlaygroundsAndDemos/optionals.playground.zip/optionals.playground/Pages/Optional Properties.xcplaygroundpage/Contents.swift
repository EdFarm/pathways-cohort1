//: ## Optional Properties
struct Musician {
  var firstName: String
  var lastName: String? // we've added the ? here
}

var prince = Musician(firstName: "Prince", lastName: "") // does this work?

var pink = Musician(firstName: "P!nk", lastName: nil)
// works this time!

prince.lastName = nil // now we can fix that first example too

print(prince.lastName)
//: [Previous](@previous) | [Next](@next)
