//: ## Optional Chaining
/*:
 - callout(What if...):
 Our types need to have nested optional values?
 */
struct Route {
  var name: String
  var stops: [String]
  var driver: Driver?
}

struct Driver {
  var firstName: String
  var bus: Bus?
  var address: Address?
}

struct Address {
  var street: String
  var unit: String?
}

let bus = Bus(number: "ABC123")
let driver = Driver(firstName: "Janet", bus: bus)
let route = Route(name: "Route 1", stops:["121 Main St"], driver: driver)

// route with a driver, but no bus
let noBusDriver = Driver(firstName: "Bill")
let noBusRoute = Route(name: "Route 66", stops: ["1919 Piedmont Ave"], driver: noBusDriver)

// route with no driver, and thus, no bus
let noDriverRoute = Route(name: "Route 2", stops: ["1914 4th Ave N"], driver: nil)

// optional chaining
// pyramid of doom!!
if let realDriver = route.driver {
  if let realBus = realDriver.bus {
    print("\(realDriver.firstName) is the driver of \(realBus.number) on \(route.name)")
  }
}

/*:
 - callout(An Easier Way):
 Check this out...
 */
if let busNumber = route.driver?.bus?.number {
  print(busNumber)
}

if let maybeBusNumber = noDriverRoute.driver?.bus?.number {
  print(maybeBusNumber)
} else {
  print("can't find bus number in optional chain")
}

if let anotherPossibleNumber = noBusRoute.driver?.bus?.number {
  print(anotherPossibleNumber)
} else {
  print("Nope. Nothing found for another possible number in optional chain.")
}

// flow of optional chaining
// route.driver?.bus?.number___> value
//             \\   \\
//              \\___\\________> nil
//: [Previous](@previous) | [Next](@next)
import Foundation
