//: ## Optional Binding
/*:
 - callout(What if...):
 There was a better way to unwrap the values?
 */
let bus: Bus? = Bus(number: "ABC123")
let maybeBus: Bus? = nil

// if let syntax
if let realBus = bus {
  print(realBus.number)
}

// if let - else syntax
if let anotherBus = maybeBus { // is maybeBus nil? assign to anotherBus
  print(anotherBus.number)
} else {
  print("that's not a bus, it's NIL!")
}

//: [Previous](@previous) | [Next](@next)


import Foundation
