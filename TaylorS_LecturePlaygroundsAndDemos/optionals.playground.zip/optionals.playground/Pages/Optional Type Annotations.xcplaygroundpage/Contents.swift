//: ## Optional Type Annotations
/*:
 - callout(What if...):
 We need to search for a bus in our system that _might_ exist, or _might_ not?
 */
var aBus = Bus(number: "ABC123") // inferred type, not optional
var possibleBus: Bus? = Bus(number: "XYZ789") // annotated with optional
// no type annotation here... does this work?
//var anotherPossibleBus = nil

var oneMorePossibleBus: Bus? = nil // with optional annotation
//: [Previous](@previous) | [Next](@next)


import Foundation
