//: ## Failable Initializers
/*:
 - callout(What if...):
 An initializer could result in an optional value?
 */
class Driver {
  var firstName: String
  var age: Int
  
  static let minimumDriverAge = 25
  
  init?(firstName: String, age: Int) {
    if age < Driver.minimumDriverAge {
      return nil
    } else {
      self.firstName = firstName
      self.age = age
    }
  }
}

if let maybeDriver = Driver(firstName: "Janet", age: 37) {
  print(maybeDriver.firstName)
}

if let babyDriver = Driver(firstName: "Billy", age: 2) {
  print(babyDriver.firstName)
} else {
  print("Driver was too young!")
}
//: [Previous](@previous) | [Next](@next)
import Foundation
