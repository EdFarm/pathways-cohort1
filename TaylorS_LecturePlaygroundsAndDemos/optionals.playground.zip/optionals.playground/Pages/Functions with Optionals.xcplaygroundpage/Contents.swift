//: ## Functions with Optionals
/*:
 - callout(What if...):
 We need to use an optional with a function?
 */
func printMusicianName(firstName: String, lastName: String?) {
  if let lname = lastName {
    print("\(firstName) \(lname) is the musician's name")
  } else {
    print("\(firstName) is the musician's name" )
  }
}

printMusicianName(firstName: "Cher", lastName: nil)

printMusicianName(firstName: "Jimmy", lastName: "Buffett")
//: [Previous](@previous) | [Next](@next)
import Foundation
