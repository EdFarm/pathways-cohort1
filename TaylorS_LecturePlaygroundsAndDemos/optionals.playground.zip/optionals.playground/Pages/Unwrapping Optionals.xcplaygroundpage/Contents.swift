//: ## Force Unwrapping
/*:
 - callout(What if...):
 We wanted to stop worrying about if something is nil and __use it!__
 */
let bus: Bus? = Bus(number: "ABC123")
let maybeBus: Bus? = nil

if bus != nil {
  let realBus = bus! // force unwrap here
  print(realBus.number)
}

let anotherBus = maybeBus! // force unwrapping nil = OH NO!
//: [Previous](@previous) | [Next](@next)


import Foundation
