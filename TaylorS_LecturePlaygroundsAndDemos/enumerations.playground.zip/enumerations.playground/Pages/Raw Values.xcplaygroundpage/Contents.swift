//: ## Raw Values
/*:
 - Callout(What if...): We wanted our enums values to represent more useful values?
 */
// shorter syntax for defining the enum
enum BusSeatPosition: String {
  case driverWindow, driverAisle, passengerAisle, passengerWindow
}

print(BusSeatPosition.driverWindow.rawValue)

//enum BusRow: Int {
//  case first = 1
//  case second = 2
//  case third = 3
//  case fourth = 4
//  case fifth = 5
//  case sixth = 6
//  case seventh = 7
//  case eighth = 8
//  case ninth = 9
//  case tenth = 10
//}

// implicitly assigned raw values
enum BusRow: Int{
  case first = 1, second, third, fourth, fifth, sixth, seventh, eighth, ninth, tenth
}

struct BusSeat {
  var position: BusSeatPosition
  var row: Int
  
  init(position: BusSeatPosition, row: BusRow) {
    self.position = position
    self.row = row.rawValue
  }
}
//: ---
var frontSeat = BusSeat(position: BusSeatPosition.driverWindow, row: BusRow.first)
var middleSeat = BusSeat(position: .passengerAisle, row: .fifth)
var backSeat = BusSeat(position: .passengerWindow, row: .tenth)

print("Your seat is \(frontSeat.position), row \(frontSeat.row)")

// accessing enum case via rawValue -- result is optional!
if let longRow = BusRow(rawValue: 1) {
  print(longRow)
} else {
  print("that's not in the enum!")
}
//: [Previous](@previous) | [Next](@next)

import Foundation
