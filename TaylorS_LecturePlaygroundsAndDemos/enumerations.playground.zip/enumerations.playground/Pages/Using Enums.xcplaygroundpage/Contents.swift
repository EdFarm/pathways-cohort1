//: ## Using Enums
/*:
 - Callout(What if...): We want to use the enum values to do something?
 */
struct BusSeat {
  var position: BusSeatPosition
  var row: Int
}

// shorter syntax for defining the enum
enum BusSeatPosition {
  case driverWindow, driverAisle, passengerAisle, passengerWindow
}

var frontSeat = BusSeat(position: BusSeatPosition.driverWindow, row: 1)
var middleSeat = BusSeat(position: .passengerAisle, row: 5)
var backSeat = BusSeat(position: .passengerWindow, row: 10)
var anotherSeat = BusSeat(position: .driverAisle, row: 15)
//: ---
// we can use switch to check our cases!
func seatInfo(_ seat: BusSeat) {
  switch seat.position {
  case .driverWindow:
    print("Left side window view for me!")
  case .driverAisle:
    print("Left side aisle for me!")
  case .passengerAisle:
    print("Right side aisle for me!")
  case .passengerWindow:
    print("Right side window for me!")
  }
}

var seats = [frontSeat, middleSeat, backSeat, anotherSeat]

for seat in seats {
  seatInfo(seat)
}
//: ---
// can also use if
func checkView(seat: BusSeat) {
  if seat.position == .driverWindow || seat.position == .passengerWindow {
    print("Hey! I've got a good view!")
  } else {
    print("At least I'll have more leg room!")
  }
}

checkView(seat: middleSeat)
//: [Previous](@previous) | [Next](@next)

import Foundation
