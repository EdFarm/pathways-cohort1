//: ## Defining Enums
/*:
 - Callout(What if...): We want to store a value that is one of a limited set of options?
 */
struct BusSeat {
  var position: BusSeatPosition
  var row: Int
}

enum BusSeatPosition {
  case driverWindow
  case driverAisle
  case passengerWindow
  case passengerAisle
}
/*:
 - Example: Before..\
 `var frontSeat = BusSeat(position: "left window", row: 1)`\
 `var backSeat = BusSeat(position: "right window", row: 10)`\
 `var anotherSeat = BusSeat(position: "middle of the aisle", row: 8)`
 */
var frontSeat = BusSeat(position: BusSeatPosition.driverWindow, row: 1)
var backSeat = BusSeat(position: .passengerWindow, row: 10)
//var anotherSeat = BusSeat(position: .middleOfTheAisle, row: 8)
//: [Previous](@previous) | [Next](@next)

import Foundation
