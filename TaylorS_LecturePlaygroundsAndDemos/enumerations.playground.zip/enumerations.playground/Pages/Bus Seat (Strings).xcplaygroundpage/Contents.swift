//: ## Defining Enums
/*:
 - Callout(What if...): We want to store a value that is one of a limited set of options?
 */
struct BusSeat {
  var position: String
  var row: Int
}

var frontSeat = BusSeat(position: "left window", row: 1)
var backSeat = BusSeat(position: "Right window", row: 10)

var anotherSeat = BusSeat(position: "middle of the aisle", row: 8)
//: [Previous](@previous) | [Next](@next)


import Foundation
