//: # Enumerations ("Enums")
/*:
 ## Lesson Plan
 - Defining Enumerations
 - Raw Values
 - Enumerations and Switch
 */
//: [Previous](@previous) | [Next](@next)
